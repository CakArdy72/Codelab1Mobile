package com.example.project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
